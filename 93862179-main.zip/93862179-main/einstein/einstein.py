m = input("m: ")
e = int(m)*300000000*300000000
print(f"E: {e}")